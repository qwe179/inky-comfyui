#!/usr/bin/env python3
"""옷 한 벌로 모션을 일괄로 뽑기 2단계 (RunPod의 ComfyUI Pod): 작업마다 R2V를 돌려 gif를 받아 온다.

사용법 (Pod 터미널):
  python3 run_batch.py work/plate/jobs.json --workflow r2v_template_api.json [--server http://127.0.0.1:8188]
        [--takes 1] [--only attack_one_hand,thrust_one_hand] [--dirs south,east] [--limit 5] [--dry-run]
        [--redo work/plate/redo.json]

  jobs.json         prep_batch.py가 만든 작업 목록 (같은 폴더의 inputs/ 에 참조 그림·프레임이 있어야 한다)
  --workflow        ComfyUI에서 h3_r2v_plate_attack_nw.json을 열고 "Workflow > Export (API)"로 저장한 파일 (README 참고)
  --takes N         작업마다 시드를 바꿔 N번 뽑는다 (기본 1). 결과는 results/<작업>/take1.gif, take2.gif ...
  --only, --dirs    일부 모션·방향만
  --limit N         이번 실행에서 N개까지만 (시험용)
  --redo redo.json  pick_frames.py가 적은 "다시 뽑기" 작업만, 적힌 take 번호들(= 다른 시드)로 뽑는다. 모든 작업의 첫 take를 먼저 돈다
  --dry-run         서버에 안 보내고 바뀔 값만 확인한다 (노드 번호·입력 이름 검사 포함)

이어서 하기: 이미 results에 gif가 있는 작업은 건너뛴다. 실패한 작업은 status.json에 적고 다음으로 넘어간다.
필요: 파이썬 표준 라이브러리 + (mp4 만들 때만) av, numpy, Pillow — ComfyUI Pod에 이미 있다.
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import uuid

# 워크플로(h3_r2v_plate_attack_nw)에서 바꾸는 노드. API 내보내기 파일에서도 노드 번호는 같다.
# (노드 번호, 클래스 이름, [입력 이름 후보...])
NODES = {
    'ref_image':  ('137', 'LoadImage', ['image']),
    'ref_video':  ('147', 'LoadVideo', ['file', 'video']),
    'prompt':     ('138', 'PrimitiveStringMultiline', ['value', 'text']),
    'duration':   ('132', 'PrimitiveFloat', ['value']),
    'seed':       ('129', 'RandomNoise', ['noise_seed']),
    'scale_by':   ('149', 'ImageScaleBy', ['scale_by']),
    'save':       ('150', 'VHS_VideoCombine', ['filename_prefix']),
}
BASE_SEED = 12345


def key_for(wf, what):
    """워크플로에서 바꿀 (노드 번호, 입력 이름)을 찾는다. 못 찾으면 이유를 알려 주고 멈춘다."""
    nid, cls, names = NODES[what]
    node = wf.get(nid)
    if node is None:
        sys.exit(f'워크플로에 노드 {nid}({cls})가 없다. h3_r2v_plate_attack_nw.json을 그대로 Export (API) 했는지 확인.')
    if node.get('class_type') != cls:
        sys.exit(f'노드 {nid}가 {cls}가 아니라 {node.get("class_type")}이다. 워크플로가 바뀌었으면 run_batch.py의 NODES를 고친다.')
    for n in names:
        if n in node['inputs']:
            return nid, n
    sys.exit(f'노드 {nid}({cls})에 입력 {names}가 없다. 있는 입력: {list(node["inputs"])}')


def patch(wf, job, ref_name, mp4_name, seed, take):
    wf = json.loads(json.dumps(wf))
    vals = {
        'ref_image': ref_name, 'ref_video': mp4_name, 'prompt': job['prompt'], 'duration': job['duration'],
        'seed': seed, 'scale_by': 1.0 / job['scale'],
        'save': f'r2vbatch_{job["job"]}_take{take}',
    }
    for what, v in vals.items():
        nid, name = key_for(wf, what)
        wf[nid]['inputs'][name] = v
    return wf


def make_mp4(frames_dir, dst, repeat=6, fps=24):
    import av
    import numpy as np
    from PIL import Image
    files = sorted(f for f in os.listdir(frames_dir) if f.startswith('frame_') and f.endswith('.png'))
    out = av.open(dst, 'w')
    first = Image.open(os.path.join(frames_dir, files[0])).convert('RGB')
    s = out.add_stream('libx264', rate=fps)
    s.width, s.height, s.pix_fmt = first.size[0], first.size[1], 'yuv420p'
    s.options = {'crf': '10'}
    for f in files:
        img = np.array(Image.open(os.path.join(frames_dir, f)).convert('RGB'))
        for _ in range(repeat):
            for p in s.encode(av.VideoFrame.from_ndarray(img, format='rgb24')):
                out.mux(p)
    for p in s.encode():
        out.mux(p)
    out.close()


def server_up(server):
    try:
        urllib.request.urlopen(server.rstrip('/') + '/system_stats', timeout=10).read()
        return True
    except Exception:
        return False


def wait_server(server, minutes=10):
    """ComfyUI가 응답할 때까지 기다린다. minutes 안에 안 살아나면 False."""
    t0 = time.time()
    while time.time() - t0 < minutes * 60:
        if server_up(server):
            return True
        time.sleep(15)
    return False


class Comfy:
    def __init__(self, server):
        self.s = server.rstrip('/')
        self.cid = uuid.uuid4().hex

    def _get(self, path):
        with urllib.request.urlopen(self.s + path, timeout=60) as r:
            return r.read()

    def upload(self, path, name):
        """input 폴더에 파일을 올린다 (이미지·mp4 모두 /upload/image로 올라간다)."""
        b = uuid.uuid4().hex
        data = open(path, 'rb').read()
        body = b''
        for k, v in (('overwrite', 'true'), ('type', 'input')):
            body += f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
        body += (f'--{b}\r\nContent-Disposition: form-data; name="image"; filename="{name}"\r\n'
                 f'Content-Type: application/octet-stream\r\n\r\n').encode() + data + f'\r\n--{b}--\r\n'.encode()
        req = urllib.request.Request(self.s + '/upload/image', data=body, headers={'Content-Type': f'multipart/form-data; boundary={b}'})
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read())['name']

    def queue(self, wf):
        req = urllib.request.Request(self.s + '/prompt', data=json.dumps({'prompt': wf, 'client_id': self.cid}).encode(),
                                     headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read())['prompt_id']
        except urllib.error.HTTPError as e:
            sys.exit('ComfyUI가 워크플로를 거부했다: ' + e.read().decode('utf-8', 'ignore')[:1500])

    def wait(self, pid, timeout=1800):
        t0 = time.time()
        while time.time() - t0 < timeout:
            h = json.loads(self._get('/history/' + pid))
            if pid in h:
                st = h[pid].get('status', {})
                if st.get('status_str') == 'error':
                    raise RuntimeError('ComfyUI 실행 오류: ' + json.dumps(st.get('messages', [])[-1:], ensure_ascii=False)[:800])
                if h[pid].get('outputs'):
                    return h[pid]['outputs']
            time.sleep(3)
        raise TimeoutError('결과를 기다리다 시간 초과')

    def download(self, info, dst):
        q = urllib.parse.urlencode({'filename': info['filename'], 'subfolder': info.get('subfolder', ''), 'type': info.get('type', 'output')})
        open(dst, 'wb').write(self._get('/view?' + q))


def pick_gif(outputs):
    for node_out in outputs.values():
        for key in ('gifs', 'images'):
            for it in node_out.get(key, []):
                if it['filename'].lower().endswith('.gif'):
                    return it
    return None


def main():
    args = sys.argv[1:]
    if not args or args[0].startswith('-'):
        print(__doc__)
        sys.exit(1)
    jobs_path = os.path.abspath(args[0])
    opt = {'--workflow': None, '--server': 'http://127.0.0.1:8188', '--takes': '1', '--only': None, '--dirs': None, '--limit': None, '--redo': None}
    dry = False
    i = 1
    while i < len(args):
        if args[i] == '--dry-run':
            dry = True
            i += 1
        elif args[i] in opt:
            opt[args[i]] = args[i + 1]
            i += 2
        else:
            sys.exit('모르는 옵션: ' + args[i])
    if not opt['--workflow']:
        sys.exit('--workflow (API 형식 json)가 필요하다. README의 "워크플로 내보내기" 참고.')
    wf = json.load(open(opt['--workflow'], encoding='utf-8'))
    if 'nodes' in wf:
        sys.exit('이 파일은 화면용 형식이다. ComfyUI에서 "Workflow > Export (API)"로 저장한 파일을 쓴다.')
    root = os.path.dirname(jobs_path)
    jobs = json.load(open(jobs_path, encoding='utf-8'))['jobs']
    only = set(opt['--only'].split(',')) if opt['--only'] else None
    dirs = set(opt['--dirs'].split(',')) if opt['--dirs'] else None
    jobs = [j for j in jobs if (not only or j['motion'] in only) and (not dirs or j['dir'] in dirs)]
    takes = int(opt['--takes'])
    for what in NODES:                      # 시작 전에 한 번 검사
        key_for(wf, what)
    todo = []
    if opt['--redo']:           # 다시 뽑기: 작업마다 적힌 take 번호들
        redo = json.load(open(opt['--redo'], encoding='utf-8'))['jobs']      # {작업: [뽑을 take 번호, ...]} (pick_frames.py가 내 컴퓨터의 results를 보고 정한다. 숫자 하나도 된다)
        rounds = {}
        for j in jobs:
            ts = redo.get(j['job']) or []
            for n, t in enumerate(ts if isinstance(ts, list) else [ts]):
                if not os.path.exists(os.path.join(root, 'results', j['job'], f'take{t}.gif')):
                    rounds.setdefault(n, []).append((j, int(t)))
        for n in sorted(rounds):    # 모든 작업의 첫 take부터 돈다 (중간에 끊겨도 작업마다 하나씩은 남게)
            todo += rounds[n]
    else:
        for j in jobs:
            for t in range(1, takes + 1):
                if not os.path.exists(os.path.join(root, 'results', j['job'], f'take{t}.gif')):
                    todo.append((j, t))
    if opt['--limit']:
        todo = todo[:int(opt['--limit'])]
    print(f'할 것 {len(todo)}개 (RTX PRO 6000 기준 하나에 약 33초 -> 약 {len(todo) * 33 / 60:.0f}분, 시간당 $2.8이면 {len(todo) * 33 / 3600 * 2.8:.1f}달러 안팎)')
    if dry:
        if todo:
            j, t = todo[0]
            w = patch(wf, j, j['job'] + '_ref.png', j['job'] + '.mp4', BASE_SEED + t - 1, t)
            print('[dry-run] 첫 작업', j['job'], 'take', t)
            for what in NODES:
                nid, name = key_for(w, what)
                print(f'  {what:10s} 노드 {nid}.{name} = {str(w[nid]["inputs"][name])[:90]}')
        print('[dry-run] 서버에는 아무것도 보내지 않았다.')
        return
    c = Comfy(opt['--server'])
    status_path = os.path.join(root, 'status.json')
    status = json.load(open(status_path)) if os.path.exists(status_path) else {}
    times_path = os.path.join(root, 'times.json')          # 작업마다 걸린 초 (길이별 속도 비교용)
    times = json.load(open(times_path)) if os.path.exists(times_path) else {}
    for n, (j, t) in enumerate(todo, 1):
        name = f'{j["job"]}_take{t}'
        if not server_up(opt['--server']):         # ComfyUI가 죽어 있으면 남은 작업을 줄줄이 실패시키지 않는다
            print(f'ComfyUI({opt["--server"]})가 응답하지 않는다. 10분까지 기다린다...')
            if not wait_server(opt['--server']):
                print('ComfyUI가 살아나지 않아 멈춘다. ComfyUI를 다시 띄우고 같은 명령을 치면 끝난 작업은 건너뛰고 이어서 한다.')
                sys.exit(2)
        jdir = os.path.join(root, j.get('inputs', 'inputs'), j['job'])     # 틀린 프레임만 넣은 입력은 inputs_fix (make_fix_inputs.py)
        try:
            t0 = time.time()
            mp4 = os.path.join(jdir, j['job'] + '.mp4')
            if not os.path.exists(mp4):
                make_mp4(os.path.join(jdir, 'frames'), mp4, repeat=j.get('repeat', 6))
            ref_name = c.upload(os.path.join(jdir, 'ref.png'), j['job'] + '_ref.png')
            mp4_name = c.upload(mp4, j['job'] + '.mp4')
            pid = c.queue(patch(wf, j, ref_name, mp4_name, BASE_SEED + t - 1, t))
            outs = c.wait(pid)
            gif = pick_gif(outs)
            if not gif:
                raise RuntimeError('결과에 gif가 없다: ' + json.dumps(outs)[:300])
            dst = os.path.join(root, 'results', j['job'], f'take{t}.gif')
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            c.download(gif, dst)
            status[name] = 'ok'
            times[name] = {'seconds': round(time.time() - t0, 1), 'length': j['length'], 'orig_frames': j['n_frames']}
            json.dump(times, open(times_path, 'w'), ensure_ascii=False, indent=1)
            print(f'[{n}/{len(todo)}] {name} 완료 ({time.time() - t0:.0f}초)')
        except Exception as e:      # 한 작업이 실패해도 다음으로 간다
            status[name] = 'error: ' + str(e)[:300]
            print(f'[{n}/{len(todo)}] {name} 실패: {e}')
        json.dump(status, open(status_path, 'w'), ensure_ascii=False, indent=1)
    bad = [k for k, v in status.items() if v != 'ok']
    print(f'끝. 성공 {len(status) - len(bad)}, 실패 {len(bad)}' + (f' -> {bad[:5]}...' if bad else ''))


main()
